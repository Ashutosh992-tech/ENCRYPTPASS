package com.example.EncrptPass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncrptPassApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncrptPassApplication.class, args);
	}

}
